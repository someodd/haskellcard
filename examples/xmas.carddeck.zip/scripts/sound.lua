
if checkFlag("hasKey") then
	playSound("pop.ogg")
end
changeCurrentCard("two.card")
