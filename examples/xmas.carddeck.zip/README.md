# Xmas: Example Card Deck for haskellcard

## Credits

pop sfx
https://opengameart.org/content/bubbles-pop

tux
https://opengameart.org/content/tux-kyrodian-legends-style

mountains of christmas font
https://fonts.google.com/specimen/Mountains+of+Christmas?query=christmas

jingle bells
https://commons.wikimedia.org/wiki/File:JingleBells-Instrumental-.ogg